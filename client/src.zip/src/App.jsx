import './App.css'
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import { useEffect } from "react";
import Lenis from "@studio-freight/lenis";

import Navbar from './components/Navbar'
import Dashboard from './components/Dashboard'
import Hero from './components/Hero'
import { ThemeProvider } from 'next-themes'
import Featured from './components/Featured'
import PopularCategories from './components/PopularCategories'
import Instructors from './components/Instructors'
import ReviewsSection from './components/ReviewSection'
import Connect from './components/Connect'
import TrendingTech from './components/TrendingTech'
import Community from './components/Community'
import JoinUs from './components/JoinUs'
import Footer from './components/Footer'
import Courses from './components/Courses'
import Notifications from './components/Notifications';
import UserProfile from './components/Profile';
import LoginSection from './components/Login';
import SignUpSection from './components/SignUp';
import SettingsSection from './components/Settings';
import SupportSection from './components/Support';
import CourseDetails from './components/CourseDetails';
import LecturePage from './components/LecturePage';
import ManageCourse from './components/ManageCourse';
import InstructorProfile from './components/InstructorProfile';


function App() {
   useEffect(() => {
    const lenis = new Lenis({
      duration: 2, // scroll smoothing factor
      smooth: true,
    });

    function raf(time) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  return (
    <>
       <Router>
        <ThemeProvider>        
          <Navbar/>
          </ThemeProvider>

        <Routes>
          <Route path='/' element={<>
          <Hero/>
          <Featured/>
          <PopularCategories/>
          <Instructors/>
          <ReviewsSection/>
          <Connect/>
          <TrendingTech/>
          <Community/>
          <JoinUs/>
          </>} />
          <Route path='/dashboard' element={<Dashboard/>}/>
          <Route path='/courses' element={<Courses/>}/>
          <Route path='/notifications' element={<Notifications/>} />
          <Route path='/profile' element={<UserProfile/>}></Route>
          <Route path='/login' element = {<LoginSection/>} ></Route>
          <Route path='/signup' element = {<SignUpSection/>} ></Route>
          <Route path='/settings' element = {<SettingsSection/>} ></Route>
          <Route path='/support' element = {<SupportSection/>} ></Route>
          <Route path='/courses/:courseId' element={<CourseDetails/>} />
          <Route path="/course/:courseId/lecture/:lectureId" element = {<LecturePage/>}/>
          <Route path="/course/manage/:courseId" element = {<ManageCourse/>}/>
          <Route path="/instructor/:instructorId" element = {<InstructorProfile/>}/>
        </Routes>
        <Footer/>
       </Router>
    </>
  )
}

export default App
