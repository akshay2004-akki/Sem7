import asyncHandler from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { Course } from "../models/courses.model.js";
import { isValidObjectId } from "mongoose";
import { uploadOnCloudinary } from "../utils/cloudinary.js";
import { User } from "../models/user.model.js";
import { sendNotification } from "./notification.controller.js";
import { Follow } from "../models/follow.model.js";

export const createCourse = asyncHandler(async (req, res) => {
  const userId = req.user?._id;
  const { title, description, category, price, language, currency } = req.body;
  if (!userId || !isValidObjectId(userId)) {
    throw new ApiError(400, "Invalid user ID");
  }
  if (!title || !description || !category || !price || !language) {
    throw new ApiError(400, "All fields are required");
  }
  console.log(req.file);
  
  if (!req.file) {
    throw new ApiError(400, "Course thumbnail image is required");
  }

  const uploadedImage = await uploadOnCloudinary(
    req.file.path,
    `thumbnail/${userId}`
  );

  const newCourse = await Course.create({
    title,
    instructorId: userId,
    description,
    category,
    thumbnail: uploadedImage.secure_url,
    price,
    currency,
    language,
  });
  if (!newCourse) {
    throw new ApiError(500, "Failed to create course");
  }
  const followers = await Follow.find({ following: userId }).distinct('follower');
  await sendNotification(followers, `New course "${newCourse.title}" by ${req.user.fullName}`, `/courses/${newCourse._id}`);
  return res.status(201).json({
    newCourse,
    message: "Course created successfully",
  });
});

export const updateCourse = asyncHandler(async (req, res) => {
  const { courseId } = req.params;
  const userId = req.user?._id;
  const { title, description, category, price, language } = req.body;
  if (!courseId || !isValidObjectId(courseId)) {
    throw new ApiError(400, "Invalid course ID");
  }
  if (!userId || !isValidObjectId(userId)) {
    throw new ApiError(400, "Invalid user ID");
  }
  const course = await Course.findById(courseId);
  if (!course) {
    throw new ApiError(404, "Course not found");
  }
  if (course.instructorId.toString() !== userId.toString()) {
    throw new ApiError(403, "You are not authorized to update this course");
  }
  if (!req.file || !req.file.buffer) {
    throw new ApiError(400, "Course thumbnail image is required");
  }
  const uploadedImage = await uploadOnCloudinary(
    req.file.buffer,
    `thumbnail/${userId}`
  );
  const updatedCourse = await Course.findByIdAndUpdate(
    courseId,
    {
      title,
      description,
      category,
      thumbnail: uploadedImage.secure_url,
      price,
      language,
    },
    { new: true }
  );
  if (!updatedCourse) {
    throw new ApiError(500, "Failed to update course");
  }
  return res.status(200).json({
    updatedCourse,
    message: "Course updated successfully",
  });
});

export const deleteCourse = asyncHandler(async (req, res) => {
  const { courseId } = req.params;
  const userId = req.user?._id;
  if (!courseId || !isValidObjectId(courseId)) {
    throw new ApiError(400, "Invalid course ID");
  }
  if (!userId || !isValidObjectId(userId)) {
    throw new ApiError(400, "Invalid user ID");
  }
  const course = await Course.findById(courseId);
  if (!course) {
    throw new ApiError(404, "Course not found");
  }
  if (course.instructorId.toString() !== userId.toString()) {
    throw new ApiError(403, "You are not authorized to delete this course");
  }
  await Course.findByIdAndDelete(courseId);
  return res.status(200).json({
    message: "Course deleted successfully",
  });
});

export const getCourseById = asyncHandler(async (req, res) => {
  const { courseId } = req.params;
  if (!courseId || !isValidObjectId(courseId)) {
    throw new ApiError(400, "Invalid course ID");
  }

  const course = await Course.findById(courseId)
    .populate("instructorId", "fullName email")
    .populate({
      path: "sections",
      populate: {
        path: "lectures",
        model: "Lecture", // 👈 make sure this matches your model name
      },
    });

  if (!course) {
    throw new ApiError(404, "Course not found");
  }

  return res.status(200).json({
    course,
    message: "Course retrieved successfully",
  });
});


export const getInstructorCourses = asyncHandler(async (req, res) => {
  const { instructorId } = req.params;
  if (!instructorId || !isValidObjectId(instructorId)) {
    throw new ApiError(400, "Invalid instructor ID");
  }
  const courses = await Course.find({ instructorId }).populate(
    "instructorId",
    "fullName email"
  );
  if (!courses || courses.length === 0) {
    return res.status(404).json({
      message: "No courses found for this instructor",
    });
  }
  console.log(courses);
  
  return res.status(200).json({
    courses,
    message: "Courses retrieved successfully",
  });
});

export const getAllCourses = asyncHandler(async (req, res) => {
  const courses = await Course.find().populate("instructorId", "fullName");
  if (!courses || courses.length === 0) {
    return res.status(404).json({
      message: "No courses found",
    });
  }
  return res.status(200).json({
    courses,
    message: "Courses retrieved successfully",
  });
});



export const browseCourses = asyncHandler(async (req, res) => { 
  try {
    const { search = "" } = req.query;

    // If search is empty, return all or empty array
    if (!search.trim()) {
      return res.status(200).json([]);
    }

    // ✅ Safely escape all regex special characters
    const escapeRegex = (str) =>
      str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

    const safeSearch = escapeRegex(search.trim());
    const regex = new RegExp(safeSearch, "i"); // case-insensitive

    // ✅ Search only in title
    const courses = await Course.find({
      title: { $regex: regex },
    });

    res.status(200).json(courses);
  } catch (err) {
    console.error("Search error:", err);
    res.status(500).json({ message: "Server error" });
  }
});



export const enrollInCourse = asyncHandler(async(req,res)=>{
  const {courseId} = req.params;
  const userId = req.user?._id;
  if(!courseId || !isValidObjectId(courseId)){
    throw new ApiError(400, "Invalid course ID");
  }
  if(!userId || !isValidObjectId(userId)){
    throw new ApiError(400, "Invalid user ID");
  }
  const course = await Course.findById(courseId);
  if(!course){
    throw new ApiError(404, "Course not found");
  }   
  const user = await User.findById(userId);
  if(user.enrolledCourses.includes(courseId)){
    throw new ApiError(400, "You are already enrolled in this course");
  }
  user.enrolledCourses.push(courseId);
  await user.save();
  return res.status(200).json({
    message: "Enrolled in course successfully"
  });
});

export const getEnrolledCourses = asyncHandler(async(req,res)=>{
  const userId = req.user?._id;
  if(!userId || !isValidObjectId(userId)){
    throw new ApiError(400, "Invalid user ID");
  }
  const user = await User.findById(userId).populate("enrolledCourses");
  if(!user){
    throw new ApiError(404, "User not found");
  } 
  return res.status(200).json({
    enrolledCourses: user.enrolledCourses,
    message: "Enrolled courses retrieved successfully"
  });
});

export const isUserEnrolled = asyncHandler(async(req,res)=>{
  const userId = req.user?._id;
  const {courseId} = req.params;
  if(!courseId || !isValidObjectId(courseId)){
    throw new ApiError(400, "Invalid course ID");
  }
  if(!userId || !isValidObjectId(userId)){
    throw new ApiError(400, "Invalid user ID");
  }
  const user = await User.findById(userId);
  if(!user){
    throw new ApiError(404, "User not found");
  } 
  const isEnrolled = user.enrolledCourses.includes(courseId);
  return res.status(200).json({
    isEnrolled,
    message: "Enrollment status retrieved successfully"
  });
});


